# end-to-end-binary-heart-disease-classification
  This notebook looks into using various Python-based ML and data science  libraries in an attempt to bulid a ML model capable of predicting whether  or not someone has a heart disease based on their medical attributes
