#!/usr/bin/env python
# coding: utf-8

# ## 157 Predict heart disease using machine learning
# This notebook will introduce some foundation machine learning and data science concepts by exploring the problem of heart disease **classification**.
# 
# It is intended to be an end-to-end example of what a data science and machine learning **proof of concept** might look like.
# 
# ## What is classification?
# 
# Classification involves deciding whether a sample is part of one class or another (**single-class classification**). If there are multiple class options, it's referred to as **multi-class classification**.
# 
# 
# ## What we'll end up with
# 
# Since we already have a dataset, we'll approach the problem with the following machine learning modelling framework.
# More specifically, we'll look at the following topics.
# 
# * **Exploratory data analysis (EDA)** - the process of going through a dataset and finding out more about it.
# * **Model training** - create model(s) to learn to predict a target variable based on other variables.
# * **Model evaluation** - evaluating a models predictions using problem-specific evaluation metrics. 
# * **Model comparison** - comparing several different models to find the best one.
# * **Model fine-tuning** - once we've found a good model, how can we improve it?
# * **Feature importance** - since we're predicting the presence of heart disease, are there some things which are more important for prediction?
# * **Cross-validation** - if we do build a good model, can we be sure it will work on unseen data?
# * **Reporting what we've found** - if we had to present our work, what would we show someone?
# 
# To work through these topics, we'll use pandas, Matplotlib and NumPy for data anaylsis, as well as, Scikit-Learn for machine learning and modelling tasks.
# 
# This notebook looks into using various Python-based ML and data science 
# libraries in an attempt to bulid a ML model capable of predicting whether 
# or not someone has a heart disease based on their medical attributes
# 
# We'll work through each step and by the end of the notebook, we'll have a handful of models, all which can predict whether or not a person has heart disease based on a number of different parameters at a considerable accuracy. 
# 
# You'll also be able to describe which parameters are more indicative than others, for example, sex may be more important than age.
# 
# ### Approach
# 1. Problem definiton
# 2. Data
# 3. Evaluation
# 4. Features
# 5. Modelling
# 6. Experimentation
# 
# ## 1. Problem Definition
# In our case, the problem we will be exploring is **binary classification** (a sample can only be one of two things). 
# 
# This is because we're going to be using a number of differnet **features** (pieces of information) about a person to predict whether they have heart disease or not.
# 
# In a statement,
# > Given clinical parameters about a patient, can we predict whether or not they have heart disease?
# 
# ## 2. Data
# 
# What you'll want to do here is dive into the data your problem definition is based on. This may involve, sourcing, defining different parameters, talking to experts about it and finding out what you should expect.
# 
# The original data came from the [Cleveland database](https://archive.ics.uci.edu/ml/datasets/heart+Disease) from UCI Machine Learning Repository.
# 
# Howevever, we've downloaded it in a formatted way from [Kaggle](https://www.kaggle.com/datasets/sumaiyatasmeem/heart-disease-classification-dataset).
# 
# The original database contains 76 attributes, but here only 14 attributes will be used. **Attributes** (also called **features**) are the variables what we'll use to predict our **target variable**.
# 
# Attributes and features are also referred to as **independent variables** and a target variable can be referred to as a **dependent variable**.
# 
# > We use the independent variables to predict our dependent variable.
# 
# Or in our case, the independent variables are a patients different medical attributes and the dependent variable is whether or not they have heart disease.
# 
# ## 3. Evaluation
# The evaluation metric is something you might define at the start of a project.
# 
# Since machine learning is very experimental, you might say something like, 
# 
# > If we can reach 95% accuracy at predicting whether or not a patient has heart disease during the proof of concept, we'll pursure this project.
# 
# The reason this is helpful is it provides a rough goal for a machine learning engineer or data scientist to work towards.
# 
# However, due to the nature of experimentation, the evaluation metric may change 
# 
# ## 4. Features
# 
# Features are different parts of the data. During this step, you'll want to start finding out what you can about the data.
# 
# One of the most common ways to do this, is to create a **data dictionary**.
# 
# ### Heart Disease Data Dictionary
# 
# A data dictionary describes the data you're dealing with. Not all datasets come with them so this is where you may have to do your research or ask a **subject matter expert** (someone who knows about the data) for more.
# 
# The following are the features we'll use to predict our target variable (heart disease or no heart disease).
# 
# 1. age - age in years
# 2. sex - (1 = male; 0 = female)
# 3. cp - chest pain type
#     0: Typical angina: chest pain related decrease blood supply to the heart
#     1: Atypical angina: chest pain not related to heart
#     2: Non-anginal pain: typically esophageal spasms (non heart related)
#     3: Asymptomatic: chest pain not showing signs of disease
# 4. trestbps - resting blood pressure (in mm Hg on admission to the hospital) anything above 130-140 is typically cause for concern
# 5. chol - serum cholestoral in mg/dl
#     serum = LDL + HDL + .2 * triglycerides
#     above 200 is cause for concern
# 6. fbs - (fasting blood sugar > 120 mg/dl) (1 = true; 0 = false)
#     '>126' mg/dL signals diabetes
# 7. restecg - resting electrocardiographic results
#     0: Nothing to note
#     1: ST-T Wave abnormality
#     can range from mild symptoms to severe problems
#     signals non-normal heart beat
#     2: Possible or definite left ventricular hypertrophy
#     Enlarged heart's main pumping chamber
# 8. thalach - maximum heart rate achieved
# 9. exang - exercise induced angina (1 = yes; 0 = no)
# 10. oldpeak - ST depression induced by exercise relative to rest looks at stress of heart during excercise unhealthy heart will stress more
# 11. slope - the slope of the peak exercise ST segment
#     0: Upsloping: better heart rate with excercise (uncommon)
#     1: Flatsloping: minimal change (typical healthy heart)
#     2: Downslopins: signs of unhealthy heart
# 12. ca - number of major vessels (0-3) colored by flourosopy
#     colored vessel means the doctor can see the blood passing through
#     the more blood movement the better (no clots)
# 13. thal - thalium stress result
#     1,3: normal
#     6: fixed defect: used to be defect but ok now
#     7: reversable defect: no proper blood movement when excercising
# 14. target - have disease or not (1=yes, 0=no) (= the predicted attribute)
# 

# ## 159 Preparing the tools
# 
# At the start of any project, it's custom to see the required libraries imported in a big chunk like you can see below.
# 
# However, in practice, your projects may import libraries as you go. After you've spent a couple of hours working on your problem, you'll probably want to do some tidying up. This is where you may want to consolidate every library you've used at the top of your notebook (like the cell below).
# 
# The libraries you use will differ from project to project. But there are a few which will you'll likely take advantage of during almost every structured data project. 
# 
# * [pandas](https://pandas.pydata.org/) for data analysis.
# * [NumPy](https://numpy.org/) for numerical operations.
# * [Matplotlib](https://matplotlib.org/)/[seaborn](https://seaborn.pydata.org/) for plotting or data visualization.
# * [Scikit-Learn](https://scikit-learn.org/stable/) for machine learning modelling and evaluation.

# In[22]:


// !pip install --upgrade scikit-learn


# In[23]:


# Regular EDA and plotting libraries
import numpy as np # np is short for numpy
import pandas as pd # pandas is so commonly used, it's shortened to pd
import matplotlib.pyplot as plt
import seaborn as sns # seaborn gets shortened to sns

# We want our plots to appear in the notebook
get_ipython().run_line_magic('matplotlib', 'inline')

## Models
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier

## Model evaluators
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.model_selection import RandomizedSearchCV, GridSearchCV
from sklearn.metrics import confusion_matrix, classification_report
from sklearn.metrics import precision_score, recall_score, f1_score
# from sklearn.metrics import plot_roc_curve # note: this was changed in Scikit-Learn 1.2+ to be "RocCurveDisplay" (see below)
from sklearn.metrics import RocCurveDisplay # new in Scikit-Learn 1.2+

# Print last updated
import time
print(f"Last updated: {time.asctime()}")


# ## Load Data
# 
# There are many different kinds of ways to store data. The typical way of storing **tabular data**, data similar to what you'd see in an Excel file is in `.csv` format. `.csv` stands for comma seperated values.
# 
# Pandas has a built-in function to read `.csv` files called `read_csv()` which takes the file pathname of your `.csv` file. You'll likely use this a lot.

# In[24]:


df = pd.read_csv("heart-disease.csv")
df.shape # (rows, columns)


# ## Data Exploration (exploratory data analysis or EDA)
# 
# Once you've imported a dataset, the next step is to explore. There's no set way of doing this. But what you should be trying to do is become more and more familiar with the dataset.
# 
# Compare different columns to each other, compare them to the target variable. Refer back to your **data dictionary** and remind yourself of what different columns mean.
# 
# Your goal is to become a subject matter expert on the dataset you're working with. So if someone asks you a question about it, you can give them an explanation and when you start building models, you can sound check them to make sure they're not performing too well (**overfitting**) or why they might be performing poorly (**underfitting**).
# 
# Since EDA has no real set methodolgy, the following is a short check list you might want to walk through:
# 
# 1. What question(s) are you trying to solve (or prove wrong)?
# 2. What kind of data do you have and how do you treat different types?
# 3. What’s missing from the data and how do you deal with it?
# 4. Where are the outliers and why should you care about them?
# 5. How can you add, change or remove features to get more out of your data?
# 
# Once of the quickest and easiest ways to check your data is with the `head()` function. Calling it on any dataframe will print the top 5 rows, `tail()` calls the bottom 5. You can also pass a number to them like `head(10)` to show the top 10 rows.

# In[25]:


df.head()


# In[26]:


df.tail()


# `value_counts()` allows you to show how many times each of the values of a **categorical** column appear.

# In[27]:


# Let's find out how many of each class there
df['target'].value_counts()


# Since these two values are close to even, our `target` column can be considered **balanced**. An **unbalanced** target column, meaning some classes have far more samples, can be harder to model than a balanced set. Ideally, all of your target classes have the same number of samples.
# 
# If you'd prefer these values in percentages, `value_counts()` takes a parameter, `normalize` which can be set to true.

# In[28]:


# Normalized value counts
df.target.value_counts(normalize=True)


# We can plot the target column value counts by calling the `plot()` function and telling it what kind of plot we'd like, in this case, bar is good.

# In[29]:


# Plot the value counts with a bar graph
df['target'].value_counts().plot(kind="bar", color=['salmon', 'lightblue']);


# `df.info()` shows a quick insight to the number of missing values you have and what type of data your working with.
# 
# In our case, there are no missing values and all of our columns are numerical in nature.

# In[30]:


df.info() # are there any missing values


# In[31]:


df.isna().sum()


# Another way to get some quick insights on your dataframe is to use `df.describe()`. `describe()` shows a range of different metrics about your numerical columns such as mean, max and standard deviation.

# In[32]:


df.describe()


# ### Heart Disease Frequency according to Gender
# 
# If you want to compare two columns to each other, you can use the function `pd.crosstab(column_1, column_2)`. 
# 
# This is helpful if you want to start gaining an intuition about how your independent variables interact with your dependent variables.
# 
# Let's compare our target column with the sex column. 
# 
# Remember from our data dictionary, for the target column, 1 = heart disease present, 0 = no heart disease. And for sex, 1 = male, 0 = female.

# In[33]:


df.sex.value_counts()


# There are 207 males and 96 females in our study.

# In[34]:


# Compare target column with sex column
pd.crosstab(df.target, df.sex)


# What can we infer from this? Let's make a simple heuristic.
# 
# Since there are about 100 women and 72 of them have a postive value of heart disease being present, we might infer, based on this one variable if the participant is a woman, there's a 75% chance she has heart disease.
# 
# As for males, there's about 200 total with around half indicating a presence of heart disease. So we might predict, if the participant is male, 50% of the time he will have heart disease.
# 
# Averaging these two values, we can assume, based on no other parameters, if there's a person, there's a 62.5% chance they have heart disease.
# 
# This can be our very simple **baseline**, we'll try to beat it with machine learning.

# ### Making our crosstab visual
# You can plot the crosstab by using the `plot()` function and passing it a few parameters such as, `kind` (the type of plot you want), `figsize=(length, width)` (how big you want it to be) and `color=[colour_1, colour_2]` (the different colours you'd like to use).
# 
# Different metrics are represented best with different kinds of plots. In our case, a bar graph is great. We'll see examples of more later. And with a bit of practice, you'll gain an intuition of which plot to use with different variables.

# In[35]:


# Create a plot of crosstab
pd.crosstab(df.target, df.sex).plot(kind="bar",
                                    figsize=(10, 6),
                                    color= ["salmon", "lightblue"]);

plt.title("Heart disease Frequency for Sex")
plt.xlabel("0 = No Disease, 1 = Disease")
plt.ylabel("Amount")
plt.legend(["Female", "Male"]);
plt.xticks(rotation = 0)


# ### Age vs Max Heart rate for Heart Disease
# 
# Let's try combining a couple of independent variables, such as, `age` and `thalach` (maximum heart rate) and then comparing them to our target variable `heart disease`.
# 
# Because there are so many different values for `age` and `thalach`, we'll use a scatter plot.

# In[36]:


# Create another figure
plt.figure(figsize=(10, 6))

# Scatter with positive examples
plt.scatter(df.age[df.target==1],
            df.thalach[df.target==1],
            c="salmon");

# Scatter with negative examples
plt.scatter(df.age[df.target==0],
            df.thalach[df.target==0],
            c="lightblue");

# Add some helpful info
plt.title("Heart Disease in function of Age and Max Heart Rate")
plt.xlabel("Age")
plt.ylabel("Max Heart Rate")
plt.legend(["Disease", "No Disease"]);


# What can we infer from this?
# 
# It seems the younger someone is, the higher their max heart rate (dots are higher on the left of the graph) and the older someone is, the more green dots there are. But this may be because there are more dots all together on the right side of the graph (older participants).
# 
# Both of these are observational of course, but this is what we're trying to do, build an understanding of the data.
# 
# Let's check the age **distribution**.

# In[37]:


# Check the distribution of the age column with a histogram
df.age.plot.hist();


# ### Heart Disease Frequency per Chest Pain Type
# What can we infer from this?
# 
# Remember from our data dictionary what the different levels of chest pain are.
# 
# 3. cp - chest pain type 
#     * 0: Typical angina: chest pain related decrease blood supply to the heart
#     * 1: Atypical angina: chest pain not related to heart
#     * 2: Non-anginal pain: typically esophageal spasms (non heart related)
#     * 3: Asymptomatic: chest pain not showing signs of disease
#     
# It's interesting the atypical agina (value 1) states it's not related to the heart but seems to have a higher ratio of participants with heart disease than not.
# 
# Wait...?
# 
# What does atypical agina even mean?
# 
# At this point, it's important to remember, if your data dictionary doesn't supply you enough information, you may want to do further research on your values. This research may come in the form of asking a **subject matter expert** (such as a cardiologist or the person who gave you the data) or Googling to find out more.
# 
# According to PubMed, it seems [even some medical professionals are confused by the term](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2763472/).
# 
# > Today, 23 years later, “atypical chest pain” is still popular in medical circles. Its meaning, however, remains unclear. A few articles have the term in their title, but do not define or discuss it in their text. In other articles, the term refers to noncardiac causes of chest pain.
# 
# Although not conclusive, this graph above is a hint at the confusion of defintions being represented in data.

# In[38]:


pd.crosstab(df.cp, df.target)


# In[39]:


# Make the crosstab more visual
pd.crosstab(df.cp, df.target).plot(kind='bar',
                                   figsize=(10, 6),
                                   color=['salmon', 'lightblue'])

# Add some communication
plt.title("Heart Disease Frequency per Chest Pain Type")
plt.xlabel("Chest Pain Type")
plt.ylabel("Amount")
plt.legend(["No Disease", "Disease"]);
plt.xticks(rotation = 0);


# ### 163 Finding Patterns 3

# In[40]:


df.head()


# ### Correlation between independent variables
# 
# Finally, we'll compare all of the independent variables in one hit.
# 
# Why?
# 
# Because this may give an idea of which independent variables may or may not have an impact on our target variable.
# 
# We can do this using `df.corr()` which will create a [**correlation matrix**](https://www.statisticshowto.datasciencecentral.com/correlation-matrix/) for us, in other words, a big table of numbers telling us how related each variable is the other.

# In[41]:


# Find the correlation between our independent variables
corr_matrix = df.corr()
corr_matrix 


# In[42]:


# Let's make it look a little prettier
corr_matrix = df.corr()
plt.figure(figsize=(15, 10))
sns.heatmap(corr_matrix, 
            annot=True, 
            linewidths=0.5, 
            fmt= ".2f", 
            cmap="YlGnBu");


# Much better. A higher positive value means a potential positive correlation (increase) and a higher negative value means a potential negative correlation (decrease).

# In[43]:


get_ipython().system('pip install --upgrade seaborn')


# ### Enough EDA, let's model
# 
# Remember, we do exploratory data analysis (EDA) to start building an intuitition of the dataset.
# 
# What have we learned so far? Aside from our basline estimate using `sex`, the rest of the data seems to be pretty distributed.
# 
# So what we'll do next is **model driven EDA**, meaning, we'll use machine learning models to drive our next questions.
# 
# A few extra things to remember:
# 
# * Not every EDA will look the same, what we've seen here is an example of what you could do for structured, tabular dataset.
# * You don't necessarily have to do the same plots as we've done here, there are many more ways to visualize data, I encourage you to look at more.
# * We want to quickly find:
#     * Distributions (`df.column.hist()`)
#     * Missing values (`df.info()`)
#     * Outliers
# 
# Let's build some models.
# 
# ---

# ## 5. Modeling
# 
# We've explored the data, now we'll try to use machine learning to predict our target variable based on the 13 independent variables.
# 
# Remember our problem?
# 
# > Given clinical parameters about a patient, can we predict whether or not they have heart disease?
# 
# That's what we'll be trying to answer.
# 
# And remember our evaluation metric?
# 
# > If we can reach 95% accuracy at predicting whether or not a patient has heart disease during the proof of concept, we'll pursure this project.
# 
# That's what we'll be aiming for.
# 
# But before we build a model, we have to get our dataset ready.
# 
# Let's look at it again.

# ## 164 5. Modelling

# In[45]:


df.head()


# In[46]:


# Split the data into X and y
X = df.drop("target", axis=1)

# Target variable
y = df["target"]


# In[47]:


# independent variables (no target column)
X.head()


# In[48]:


# Targets
y


# In[49]:


# Split data into train and test sets
np.random.seed(42)

# Split into train and test set
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2)


# In[50]:


X_train


# ### Training and test split
# 
# Now comes one of the most important concepts in machine learning, the **training/test split**.
# 
# This is where you'll split your data into a **training set** and a **test set**.
# 
# You use your training set to train your model and your test set to test it.
# 
# The test set must remain separate from your training set.
# 
# #### Why not use all the data to train a model?
# 
# Let's say you wanted to take your model into the hospital and start using it on patients. How would you know how well your model goes on a new patient not included in the original full dataset you had?
# 
# This is where the test set comes in. It's used to mimic taking your model to a real environment as much as possible.
# 
# And it's why it's important to never let your model learn from the test set, it should only be evaluated on it.
# 
# To split our data into a training and test set, we can use Scikit-Learn's [`train_test_split()`](https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.train_test_split.html) and feed it our independent and dependent variables (`X` & `y`).

# In[51]:


# Random seed for reproducibility
np.random.seed(42)

# Split into train & test set
X_train, X_test, y_train, y_test = train_test_split(X, # independent variables 
                                                    y, # dependent variable
                                                    test_size = 0.2) # percentage of data to use for test set


# The `test_size` parameter is used to tell the `train_test_split()` function how much of our data we want in the test set.
# 
# A rule of thumb is to use 80% of your data to train on and the other 20% to test on. 
# 
# For our problem, a train and test set are enough. But for other problems, you could also use a validation (train/validation/test) set or cross-validation (we'll see this in a second).
# 
# But again, each problem will differ. The post, [How (and why) to create a good validation set](https://www.fast.ai/2017/11/13/validation-sets/) by Rachel Thomas is a good place to go to learn more.
# 
# Let's look at our training data.

# In[52]:


y_train, len(y_train)


# ## 165 Choosing the right model
# 
# ### Model choices
# 
# Now we've got our data prepared, we can start to fit models. We'll be using the following and comparing their results.
# 
# 1. Logistic Regression - [`LogisticRegression()`](https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LogisticRegression.html)
# 2. K-Nearest Neighbors - [`KNeighboursClassifier()`](https://scikit-learn.org/stable/modules/generated/sklearn.neighbors.KNeighborsClassifier.html)
# 3. RandomForest - [`RandomForestClassifier()`](https://scikit-learn.org/stable/modules/generated/sklearn.ensemble.RandomForestClassifier.html)
#  <img src='during/choose.png'/>
#  <img src='during/logistic.png'/>
#  
#  #### Why these?
# 
# If we look at the [Scikit-Learn algorithm cheat sheet](https://scikit-learn.org/stable/tutorial/machine_learning_map/index.html), we can see we're working on a classification problem and these are the algorithms it suggests (plus a few more).
# 
# | <img src="../images/sklearn-ml-map-cheatsheet-heart-disease-ensemble.png" alt="an example classification path using the Scikit-Learn machine learning model map" width=500/> | 
# |:--:| 
# | An example path we can take using the Scikit-Learn Machine Learning Map |
# 
# "Wait, I don't see Logistic Regression and why not use LinearSVC?"
# 
# Good questions. 
# 
# I was confused too when I didn't see Logistic Regression listed as well because when you read the Scikit-Learn documentation on it, you can see it's [a model for classification](https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression).
# 
# And as for LinearSVC, let's pretend we've tried it, and it doesn't work, so we're following other options in the map.
# 
# For now, knowing each of these algorithms inside and out is not essential.
# 
# Machine learning and data science is an iterative practice. These algorithms are tools in your toolbox.
# 
# In the beginning, on your way to becoming a practioner, it's more important to understand your problem (such as, classification versus regression) and then knowing what tools you can use to solve it.
# 
# Since our dataset is relatively small, we can experiment to find algorithm performs best.
# 
# All of the algorithms in the Scikit-Learn library use the same functions, for training a model, `model.fit(X_train, y_train)` and for scoring a model `model.score(X_test, y_test)`. `score()` returns the ratio of correct predictions (1.0 = 100% correct).
# 
# Since the algorithms we've chosen implement the same methods for fitting them to the data as well as evaluating them, let's put them in a dictionary and create a which fits and scores them.

# In[53]:


# Put models in a dictionary
models = {"Logistic Regression": LogisticRegression(),
          #Logistic Regression": LogisticRegression(max_iter=1000)
          "KNN": KNeighborsClassifier(),
          "Random Forest": RandomForestClassifier()}

# Create a function to fit and score models
def fit_and_score(models, X_train, X_test, y_train, y_test):
    """
    Fits and evaluates given ML models.
    models : a dict of different Scikit-Learn ML models
    X_train : training data (no labels)
    X_test : testing data (no labels)
    y_train : training labels
    y_test : test labels 
    """
    # Set random seed
    np.random.seed(42)

    # Make a dictionary to keep model scores
    model_scores = {}

    # Loop through models
    for name, model in models.items():
        # Fit the model to the data
        model.fit(X_train, y_train)
        # Evaluate the model and append its score to model_scores
        model_scores[name] = model.score(X_test, y_test)
    
    return model_scores

# Call the function
fit_and_score(models, X_train, X_test, y_train, y_test)


# In[54]:


model_scores = fit_and_score(models=models,
                             X_train = X_train,
                             X_test = X_test,
                             y_train = y_train,
                             y_test = y_test)

model_scores


# ## Model Comparison

# In[70]:


model_compare = pd.DataFrame(model_scores, index=["accuracy"])
model_compare.T.plot.bar();


# Beautiful! We can't really see it from the graph but looking at the dictionary, the [LogisticRegression()](https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LogisticRegression.html) model performs best.
# 
# Since you've found the best model. Let's take it to the boss and show her what we've found.
# 
# > **You:** I've found it!
# 
# > **Her:** Nice one! What did you find?
#     
# > **You:** The best algorithm for prediting heart disease is a LogisticRegrssion!
# 
# > **Her:** Excellent. I'm surprised the hyperparameter tuning is finished by now.
# 
# > **You:** *wonders what **hyperparameter tuning** is*
#     
# > **You:** Ummm yeah, me too, it went pretty quick.
#     
# > **Her:** I'm very proud, how about you put together a **classification report** to show the team, and be sure to include a **confusion matrix**, and the **cross-validated precision**, **recall** and **F1 scores**. I'd also be curious to see what **features are most important**. Oh and don't forget to include a **ROC curve**.
#     
# > **You:** *asks self, "what are those???"*
#     
# > **You:** Of course! I'll have to you by tomorrow.
# 

# Alright, there were a few words in there which could sound made up to someone who's not a budding data scientist like yourself. But being the budding data scientist you are, you know data scientists make up words all the time.
# 
# Let's briefly go through each before we see them in action.
# 
# * **Hyperparameter tuning** - Each model you use has a series of dials you can turn to dictate how they perform. Changing these values may increase or decrease model performance.
# * **Feature importance** - If there are a large amount of features we're using to make predictions, do some have more importance than others? For example, for predicting heart disease, which is more important, sex or age?
# * [**Confusion matrix**](https://www.dataschool.io/simple-guide-to-confusion-matrix-terminology/) - Compares the predicted values with the true values in a tabular way, if 100% correct, all values in the matrix will be top left to bottom right (diagnol line).
# * [**Cross-validation**](https://scikit-learn.org/stable/modules/cross_validation.html) - Splits your dataset into multiple parts and train and tests your model on each part and evaluates performance as an average. 
# * [**Precision**](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.precision_score.html#sklearn.metrics.precision_score) - Proportion of true positives over total number of samples. Higher precision leads to less false positives.
# * [**Recall**](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.recall_score.html#sklearn.metrics.recall_score) - Proportion of true positives over total number of true positives and false negatives. Higher recall leads to less false negatives.
# * [**F1 score**](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.f1_score.html#sklearn.metrics.f1_score) - Combines precision and recall into one metric. 1 is best, 0 is worst.
# * [**Classification report**](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.classification_report.html) - Sklearn has a built-in function called `classification_report()` which returns some of the main classification metrics such as precision, recall and f1-score.
# * [**ROC Curve**](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.roc_score.html) - [Receiver Operating Characterisitc](https://en.wikipedia.org/wiki/Receiver_operating_characteristic) is a plot of true positive rate versus false positive rate.
# * [**Area Under Curve (AUC)**](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.roc_auc_score.html) - The area underneath the ROC curve. A perfect model achieves a score of 1.0.

# ## 167 Tuning Improving our Model
# 
# ### Hyperparameter tuning and cross-validation
# 
# To cook your favourite dish, you know to set the oven to 180 degrees and turn the grill on. But when your roommate cooks their favourite dish, they set use 200 degrees and the fan-forced mode. Same oven, different settings, different outcomes.
# 
# The same can be done for machine learning algorithms. You can use the same algorithms but change the settings (hyperparameters) and get different results.
# 
# But just like turning the oven up too high can burn your food, the same can happen for machine learning algorithms. You change the settings and it works so well, it **overfits** (does too well) the data.
# 
# We're looking for the goldilocks model. One which does well on our dataset but also does well on unseen examples.
# 
# To test different hyperparameters, you could use a **validation set** but since we don't have much data, we'll use **cross-validation**.
# 
# The most common type of cross-validation is *k-fold*. It involves splitting your data into *k-fold's* and then testing a model on each. For example, let's say we had 5 folds (k = 5). This what it might look like.
# 
# | Normal train and test split versus 5-fold cross-validation |
# 
# We'll be using this setup to tune the hyperparameters of some of our models and then evaluate them. We'll also get a few more metrics like **precision**, **recall**, **F1-score** and **ROC** at the same time.
# 
# Here's the game plan:
# 1. Tune model hyperparameters, see which performs best
# 2. Perform cross-validation
# 3. Plot ROC curves
# 4. Make a confusion matrix
# 5. Get precision, recall and F1-score metrics
# 6. Find the most important model features
# 
# <img src="during/cr.png"/>
# 
# <img src="during/confusion_matrix.png"/>
# 
# <img src="during/cra.png"/>
# 
# Let's look at the following:
# * Hyperparameter tuning
# * Feature importance
# * Confusion matrix
# * Cross-validation
# * Precision 
# * Recall
# * F1 score
# * Classification report
# * ROC curve
# * Area under the curve (AUC)
# 

# ### Tune KNeighborsClassifier (K-Nearest Neighbors or KNN) by hand
# 
# There's one main hyperparameter we can tune for the K-Nearest Neighbors (KNN) algorithm, and that is number of neighbours. The default is 5 (`n_neigbors=5`).
# 
# What are neighbours?
# 
# Imagine all our different samples on one graph like the scatter graph we have above. KNN works by assuming dots which are closer together belong to the same class. If `n_neighbors=5` then it assume a dot with the 5 closest dots around it are in the same class.
# 
# We've left out some details here like what defines close or how distance is calculated but I encourage you to research them.
# 
# For now, let's try a few different values of `n_neighbors`.

# In[71]:


## Hyperparameter tuning for KNN model by improving n_neighbours
# Create a list of train scores
train_scores = []

# Create a list of train scores
test_scores = []

# Create a list of different values for n_neighbors
neighbors = range(1, 21)

# Setup KNN instance
knn = KNeighborsClassifier()

# Loop through different n_neighbors 
for i in neighbors:
    knn.set_params(n_neighbors=i)
    
    # Fit the algorithm
    knn.fit(X_train, y_train)
    
    # Update the test scores list
    train_scores.append(knn.score(X_train, y_train))
    
    # Update the test scoreslist
    test_scores.append(knn.score(X_test, y_test))



# In[72]:


# Let's look at KNN's train scores.
train_scores


# In[73]:


# there hard to understand, let's plot them
plt.plot(neighbors, train_scores, label="Train score")
plt.plot(neighbors, test_scores, label="Test score")
plt.xticks(np.arange(1, 21, 1))
plt.xlabel("Number of neigbors")
plt.ylabel("Model score")
plt.legend()

print(f"Maximum KNN score on the test data: {max(test_scores)* 100:.2f}%")


# Looking at the graph, `n_neighbors = 11` seems best.
# 
# Even knowing this, the `KNN`'s model performance didn't get near what `LogisticRegression` or the `RandomForestClassifier` did.
# 
# Because of this, we'll discard `KNN` and focus on the other two.
# 
# We've tuned `KNN` by hand but let's see how we can `LogisticsRegression` and `RandomForestClassifier` using [`RandomizedSearchCV`](https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.RandomizedSearchCV.html).
# 
# Instead of us having to manually try different hyperparameters by hand, `RandomizedSearchCV` tries a number of different combinations, evaluates them and saves the best.
# 
# ### Tuning models with with [`RandomizedSearchCV`](https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.RandomizedSearchCV.html)
# 
# Reading the Scikit-Learn documentation for [`LogisticRegression`](https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LogisticRegressionCV.html#sklearn.linear_model.LogisticRegressionCV), we find there's a number of different hyperparameters we can tune.
# 
# The same for [`RandomForestClassifier`](https://scikit-learn.org/stable/modules/generated/sklearn.ensemble.RandomForestClassifier.html).
# 
# Let's create a hyperparameter grid (a dictionary of different hyperparameters) for each and then test them out.

# In[74]:


# Different LogisticRegression hyperparameters
log_reg_grid = {"C": np.logspace(-4, 4, 20),
                "solver": ["liblinear"]}

# Different RandomForestClassifier hyperparameters
rf_grid = {"n_estimators": np.arange(10, 1000, 50),
           "max_depth": [None, 3, 5, 10],
           "min_samples_split": np.arange(2, 20, 2),
           "min_samples_leaf": np.arange(1, 20, 2)}


# Now let's use `RandomizedSearchCV` to try and tune our `LogisticRegression` model.
# 
# We'll pass it the different hyperparameters from `log_reg_grid` as well as set `n_iter = 20`. This means, `RandomizedSearchCV` will try 20 different combinations of hyperparameters from `log_reg_grid` and save the best ones.

# In[75]:


# Setup random seed
np.random.seed(42)

# Setup random hyperparameter search for LogisticRegression
rs_log_reg = RandomizedSearchCV(LogisticRegression(),
                                param_distributions=log_reg_grid,
                                cv=5,
                                n_iter=20,
                                verbose=True)

# Fit random hyperparameter search model
rs_log_reg.fit(X_train, y_train);


# In[76]:


rs_log_reg.best_params_


# In[77]:


rs_log_reg.score(X_test, y_test)


# Now we've tuned `LogisticRegression` using `RandomizedSearchCV`, we'll do the same for `RandomForestClassifier`.

# In[78]:


# Setup random seed
np.random.seed(42)

# Setup random hyperparameter search for RandomForestClassifier
rs_rf = RandomizedSearchCV(RandomForestClassifier(),
                           param_distributions=rf_grid,
                           cv=5,
                           n_iter=20,
                           verbose=True)

# Fit random hyperparameter search model
rs_rf.fit(X_train, y_train);


# In[79]:


# Find the best parameters
rs_rf.best_params_


# In[80]:


# Evaluate the randomized search random forest model
rs_rf.score(X_test, y_test)


# Excellent! Tuning the hyperparameters for each model saw a slight performance boost in both the `RandomForestClassifier` and `LogisticRegression`.
# 
# This is akin to tuning the settings on your oven and getting it to cook your favourite dish just right.
# 
# But since `LogisticRegression` is pulling out in front, we'll try tuning it further with [`GridSearchCV`](https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.GridSearchCV.html).
# 
# ### Tuning a model with [`GridSearchCV`](https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.GridSearchCV.html)
# 
# The difference between `RandomizedSearchCV` and `GridSearchCV` is where `RandomizedSearchCV` searches over a grid of hyperparameters performing `n_iter` combinations, `GridSearchCV` will test every single possible combination.
# 
# In short:
# * `RandomizedSearchCV` - tries `n_iter` combinations of hyperparameters and saves the best.
# * `GridSearchCV` - tries every single combination of hyperparameters and saves the best.
# 
# Let's see it in action.

# In[82]:


# Different LogisticRegression hyperparameters
log_reg_grid = {"C": np.logspace(-4, 4, 20),
                "solver": ["liblinear"]}

# Setup grid hyperparameter search for LogisticRegression
gs_log_reg = GridSearchCV(LogisticRegression(),
                          param_grid=log_reg_grid,
                          cv=5,
                          verbose=True)

# Fit grid hyperparameter search model
gs_log_reg.fit(X_train, y_train);


# In[83]:


# Check the best parameters
gs_log_reg.best_params_


# In[84]:


# Evaluate the model
gs_log_reg.score(X_test, y_test)


# In this case, we get the same results as before since our grid only has a maximum of 20 different hyperparameter combinations.
# 
# **Note:** If there are a large amount of hyperparameters combinations in your grid, `GridSearchCV` may take a long time to try them all out. This is why it's a good idea to start with `RandomizedSearchCV`, try a certain amount of combinations and then use `GridSearchCV` to refine them.

# ## Evaluating a classification model, beyond accuracy
# 
# Now we've got a tuned model, let's get some of the metrics we discussed before.
# 
# We want:
# * ROC curve and AUC score - [`RocCurveDisplay()`](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.RocCurveDisplay.html) 
#     * **Note:** This was previously `sklearn.metrics.plot_roc_curve()`, as of Scikit-Learn version 1.2+, it is `sklearn.metrics.RocCurveDisplay()`.
# * Confusion matrix - [`confusion_matrix()`](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.confusion_matrix.html)
# * Classification report - [`classification_report()`](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.classification_report.html)
# * Precision - [`precision_score()`](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.precision_score.html)
# * Recall - [`recall_score()`](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.recall_score.html)
# * F1-score - [`f1_score()`](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.f1_score.html)
# 
# Luckily, Scikit-Learn has these all built-in.
# 
# To access them, we'll have to use our model to make predictions on the test set. You can make predictions by calling `predict()` on a trained model and passing it the data you'd like to predict on.
# 
# We'll make predictions on the test data.

# In[85]:


# Make preidctions on test data
y_preds = gs_log_reg.predict(X_test)


# In[86]:


y_preds


# In[87]:


y_test


# Since we've got our prediction values we can find the metrics we want.
# 
# Let's start with the ROC curve and AUC scores.
# 
# ### ROC Curve and AUC Scores
# 
# What's a ROC curve?
# 
# It's a way of understanding how your model is performing by comparing the true positive rate to the false positive rate.
# 
# In our case...
# 
# > To get an appropriate example in a real-world problem, consider a diagnostic test that seeks to determine whether a person has a certain disease. A false positive in this case occurs when the person tests positive, but does not actually have the disease. A false negative, on the other hand, occurs when the person tests negative, suggesting they are healthy, when they actually do have the disease.
# 
# Scikit-Learn implements a function `RocCurveDisplay` (previously called `plot_roc_curve` in Scikit-Learn versions > 1.2) which can help us create a ROC curve as well as calculate the area under the curve (AUC) metric.
# 
# Reading the documentation on the [`RocCurveDisplay`](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.RocCurveDisplay.html) function we can see it has a class method called [`from_estimator(estimator, X, y)`](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.RocCurveDisplay.html#sklearn.metrics.RocCurveDisplay.from_estimator) as inputs. 
# 
# Where `estiamator` is a fitted machine learning model and `X` and `y` are the data you'd like to test it on.
# 
# In our case, we'll use the GridSearchCV version of our `LogisticRegression` estimator, `gs_log_reg` as well as the test data, `X_test` and `y_test`.

# In[88]:


# Before Scikit-Learn 1.2.0 (will error with versions 1.2+)
# from sklearn.metrics import plot_roc_curve 
# plot_roc_curve(gs_log_reg, X_test, y_test);

# Scikit-Learn 1.2.0 or later
from sklearn.metrics import RocCurveDisplay 

# from_estimator() = use a model to plot ROC curve on data
RocCurveDisplay.from_estimator(estimator=gs_log_reg, 
                               X=X_test, 
                               y=y_test); 


# This is great, our model does far better than guessing which would be a line going from the bottom left corner to the top right corner, AUC = 0.5. But a perfect model would achieve an AUC score of 1.0, so there's still room for improvement.
# 
# Let's move onto the next evaluation request, a confusion matrix.
# 
# ### Confusion matrix 
# 
# A confusion matrix is a visual way to show where your model made the right predictions and where it made the wrong predictions (or in other words, got confused).
# 
# Scikit-Learn allows us to create a confusion matrix using [`confusion_matrix()`](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.confusion_matrix.html) and passing it the true labels and predicted labels.

# In[89]:


# Display confusion matrix
print(confusion_matrix(y_test, y_preds))


# As you can see, Scikit-Learn's built-in confusion matrix is a bit bland. For a presentation you'd probably want to make it visual.
# 
# Let's create a function which uses Seaborn's [`heatmap()`](https://seaborn.pydata.org/generated/seaborn.heatmap.html) for doing so.

# In[90]:


# Import Seaborn
import seaborn as sns
sns.set(font_scale=1.5) # Increase font size

def plot_conf_mat(y_test, y_preds):
    """
    Plots a confusion matrix using Seaborn's heatmap().
    """
    fig, ax = plt.subplots(figsize=(3, 3))
    ax = sns.heatmap(confusion_matrix(y_test, y_preds),
                     annot=True, # Annotate the boxes
                     cbar=False)
    plt.xlabel("true label")
    plt.ylabel("predicted label")
    
plot_conf_mat(y_test, y_preds)


# Beautiful! That looks much better. 
# 
# You can see the model gets confused (predicts the wrong label) relatively the same across both classes. In essence, there are 4 occasaions where the model predicted 0 when it should've been 1 (false negative) and 3 occasions where the model predicted 1 instead of 0 (false positive).

# ### Classification report
# 
# We can make a classification report using [`classification_report()`](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.classification_report.html) and passing it the true labels as well as our models predicted labels. 
# 
# A classification report will also give us information of the precision and recall of our model for each class.

# In[92]:


# Show classification report
print(classification_report(y_test, y_preds))


# What's going on here?
# 
# Let's get a refresh.
# 
# * **Precision** - Indicates the proportion of positive identifications (model predicted class 1) which were actually correct. A model which produces no false positives has a precision of 1.0.
# * **Recall** - Indicates the proportion of actual positives which were correctly classified. A model which produces no false negatives has a recall of 1.0.
# * **F1 score** - A combination of precision and recall. A perfect model achieves an F1 score of 1.0.
# * **Support** - The number of samples each metric was calculated on.
# * **Accuracy** - The accuracy of the model in decimal form. Perfect accuracy is equal to 1.0.
# * **Macro avg** - Short for macro average, the average precision, recall and F1 score between classes. Macro avg doesn’t class imbalance into effort, so if you do have class imbalances, pay attention to this metric.
# * **Weighted avg** - Short for weighted average, the weighted average precision, recall and F1 score between classes. Weighted means each metric is calculated with respect to how many samples there are in each class. This metric will favour the majority class (e.g. will give a high value when one class out performs another due to having more samples).
# 
# Ok, now we've got a few deeper insights on our model. But these were all calculated using a single training and test set.
# 
# What we'll do to make them more solid is calculate them using cross-validation.
# 
# How?
# 
# We'll take the best model along with the best hyperparameters and use [`cross_val_score()`](https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.cross_val_score.html) along with various `scoring` parameter values.
# 
# `cross_val_score()` works by taking an estimator (machine learning model) along with data and labels. It then evaluates the machine learning model on the data and labels using cross-validation and a defined `scoring` parameter.
# 
# Let's remind ourselves of the best hyperparameters and then see them in action.

# In[93]:


# Check best hyperparameters
gs_log_reg.best_params_


# In[94]:


# Import cross_val_score
from sklearn.model_selection import cross_val_score

# Instantiate best model with best hyperparameters (found with GridSearchCV)
clf = LogisticRegression(C=0.23357214690901212,
                         solver="liblinear")


# Now we've got an instantiated classifier, let's find some cross-validated metrics.

# In[95]:


# Cross-validated accuracy score
cv_acc = cross_val_score(clf,
                         X,
                         y,
                         cv=5, # 5-fold cross-validation
                         scoring="accuracy") # accuracy as scoring
cv_acc


# Since there are 5 metrics here, we'll take the average.

# In[97]:


cv_acc = np.mean(cv_acc)
cv_acc


# Now we'll do the same for other classification metrics.

# In[99]:


# Cross-validated precision score
cv_precision = np.mean(cross_val_score(clf,
                                       X,
                                       y,
                                       cv=5, # 5-fold cross-validation
                                       scoring="precision")) # precision as scoring
cv_precision


# In[100]:


# Cross-validated recall score
cv_recall = np.mean(cross_val_score(clf,
                                    X,
                                    y,
                                    cv=5, # 5-fold cross-validation
                                    scoring="recall")) # recall as scoring
cv_recall


# In[101]:


# Cross-validated F1 score
cv_f1 = np.mean(cross_val_score(clf,
                                X,
                                y,
                                cv=5, # 5-fold cross-validation
                                scoring="f1")) # f1 as scoring
cv_f1


# Okay, we've got cross validated metrics, now what?
# 
# Let's visualize them.

# In[103]:


# Visualizing cross-validated metrics
cv_metrics = pd.DataFrame({"Accuracy": cv_acc,
                            "Precision": cv_precision,
                            "Recall": cv_recall,
                            "F1": cv_f1},
                          index=[0])
cv_metrics.T.plot.bar(title="Cross-Validated Metrics", legend=False);


# Great! This looks like something we could share. An extension might be adding the metrics on top of each bar so someone can quickly tell what they were.
# 
# What now?
# 
# The final thing to check off the list of our model evaluation techniques is feature importance.
# 
# ## Feature importance
# 
# Feature importance is another way of asking, "which features contributing most to the outcomes of the model?"
# 
# Or for our problem, trying to predict heart disease using a patient's medical characterisitcs, which charateristics contribute most to a model predicting whether someone has heart disease or not?
# 
# Unlike some of the other functions we've seen, because how each model finds patterns in data is slightly different, how a model judges how important those patterns are is different as well. This means for each model, there's a slightly different way of finding which features were most important.
# 
# You can usually find an example via the Scikit-Learn documentation or via searching for something like "[MODEL TYPE] feature importance", such as, "random forest feature importance".
# 
# Since we're using `LogisticRegression`, we'll look at one way we can calculate feature importance for it.
# 
# To do so, we'll use the `coef_` attribute. Looking at the [Scikit-Learn documentation for `LogisticRegression`](https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LogisticRegression.html), the `coef_` attribute is the coefficient of the features in the decision function.
# 
# We can access the `coef_` attribute after we've fit an instance of `LogisticRegression`.

# In[105]:


# Fit an instance of LogisticRegression (taken from above)
clf.fit(X_train, y_train);


# In[106]:


# Check coef_
clf.coef_


# Looking at this it might not make much sense. But these values are how much each feature contributes to how a model makes a decision on whether patterns in a sample of patients health data leans more towards having heart disease or not.
# 
# Even knowing this, in it's current form, this `coef_` array still doesn't mean much. But it will if we combine it with the columns (features) of our dataframe.

# In[107]:


# Match features to columns
features_dict = dict(zip(df.columns, list(clf.coef_[0])))
features_dict


# Now we've match the feature coefficients to different features, let's visualize them. 

# In[109]:


# Visualize feature importance
features_df = pd.DataFrame(features_dict, index=[0])
features_df.T.plot.bar(title="Feature Importance", legend=False);


# You'll notice some are negative and some are positive.
# 
# The larger the value (bigger bar), the more the feature contributes to the models decision.
# 
# If the value is negative, it means there's a negative correlation. And vice versa for positive values. 
# 
# For example, the `sex` attribute has a negative value of -0.904, which means as the value for `sex` increases, the `target` value decreases.
# 
# We can see this by comparing the `sex` column to the `target` column.

# In[111]:


pd.crosstab(df["sex"], df["target"])


# You can see, when `sex` is 0 (female), there are almost 3 times as many (72 vs. 24) people with heart disease (`target` = 1) than without.
# 
# And then as `sex` increases to 1 (male), the ratio goes down to almost 1 to 1 (114 vs. 93) of people who have heart disease and who don't.
# 
# What does this mean?
# 
# It means the model has found a pattern which reflects the data. Looking at these figures and this specific dataset, it seems if the patient is female, they're more likely to have heart disease.
# 
# How about a positive correlation?

# In[113]:


# Contrast slope (positive coefficient) with target
pd.crosstab(df["slope"], df["target"])


# Looking back the data dictionary, we see `slope` is the "slope of the peak exercise ST segment" where:
# * 0: Upsloping: better heart rate with excercise (uncommon)
# * 1: Flatsloping: minimal change (typical healthy heart)
# * 2: Downslopins: signs of unhealthy heart
#     
# According to the model, there's a positive correlation of 0.470, not as strong as `sex` and `target` but still more than 0.
# 
# This positive correlation means our model is picking up the pattern that as `slope` increases, so does the `target` value.
# 
# Is this true?
# 
# When you look at the contrast (`pd.crosstab(df["slope"], df["target"]`) it is. As `slope` goes up, so does `target`. 
# 
# What can you do with this information?
# 
# This is something you might want to talk to a subject matter expert about. They may be interested in seeing where machine learning model is finding the most patterns (highest correlation) as well as where it's not (lowest correlation). 
# 
# Doing this has a few benefits:
# 1. **Finding out more** - If some of the correlations and feature importances are confusing, a subject matter expert may be able to shed some light on the situation and help you figure out more.
# 2. **Redirecting efforts** - If some features offer far more value than others, this may change how you collect data for different problems. See point 3.
# 3. **Less but better** - Similar to above, if some features are offering far more value than others, you could reduce the number of features your model tries to find patterns in as well as improve the ones which offer the most. This could potentially lead to saving on computation, by having a model find patterns across less features, whilst still achieving the same performance levels.

# ## 6. Experimentation
# 
# Well we've completed all the metrics your boss requested. You should be able to put together a great report containing a confusion matrix, a handful of cross-valdated metrics such as precision, recall and F1 as well as which features contribute most to the model making a decision.
# 
# But after all this you might be wondering where step 6 in the framework is, experimentation.
# 
# Well the secret here is, as you might've guessed, the whole thing is experimentation.
# 
# From trying different models, to tuning different models to figuring out which hyperparameters were best.
# 
# What we've worked through so far has been a series of experiments.
# 
# And the truth is, we could keep going. But of course, things can't go on forever.
# 
# So by this stage, after trying a few different things, we'd ask ourselves did we meet the evaluation metric?
# 
# Remember we defined one in step 3.
# 
# > If we can reach 95% accuracy at predicting whether or not a patient has heart disease during the proof of concept, we'll pursure this project.
# 
# In this case, we didn't. The highest accuracy our model achieved was below 90%.
# 
# #### What next?
# 
# You might be wondering, what happens when the evaluation metric doesn't get hit?
# 
# Is everything we've done wasted?
# 
# No.
# 
# It means we know what doesn't work. In this case, we know the current model we're using (a tuned version of `LogisticRegression`) along with our specific data set doesn't hit the target we set ourselves.
# 
# This is where step 6 comes into its own.
# 
# A good next step would be to discuss with your team or research on your own different options of going forward.
# 
# * Could you collect more data?
# 
# * Could you try a better model? If you're working with structured data, you might want to look into [CatBoost](https://catboost.ai/) or [XGBoost](https://xgboost.ai/).
# 
# * Could you improve the current models (beyond what we've done so far)?
# * If your model is good enough, how would you export it and share it with others? (Hint: check out [Scikit-Learn's documentation on model persistance](https://scikit-learn.org/stable/modules/model_persistence.html))
# 
# The key here is to remember, your biggest restriction will be time. Hence, why it's paramount to minimise your times between experiments.
# 
# The more you try, the more you figure out what doesn't work, the more you'll start to get a hang of what does.

# In[ ]:





# In[ ]:




